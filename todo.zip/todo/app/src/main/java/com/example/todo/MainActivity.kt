package com.example.todo

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.Spinner
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class MainActivity : AppCompatActivity() {

    private lateinit var recyclerView: RecyclerView
    private lateinit var taskViewModel: TaskViewModel
    private lateinit var sortSpinner: Spinner
    private lateinit var adapter: Adapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        // Initialize views
        val addButton = findViewById<Button>(R.id.add)
        sortSpinner = findViewById(R.id.sort_spinner) // Ensure you have added the spinner in your XML

        // Set up the add button listener
        addButton.setOnClickListener {
            startActivity(Intent(this, Activity_create_card::class.java))
        }

        // Set up RecyclerView
        recyclerView = findViewById(R.id.recycler_view)
        recyclerView.layoutManager = LinearLayoutManager(this)

        // Initialize TaskViewModel
        val taskDao = AppDatabase.getDatabase(application).taskDao()
        val repository = TaskRepository(taskDao)
        taskViewModel = TaskViewModel(repository)

        // Observe the LiveData
        taskViewModel.allTasks.observe(this) { tasks ->
            adapter = Adapter(tasks)
            recyclerView.adapter = adapter
        }

        // Set up the spinner for sorting options
        setupSpinner()
    }

    private fun setupSpinner() {
        val sortingOptions = arrayOf("Sort by Deadline", "Sort by Priority")
        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, sortingOptions)
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        sortSpinner.adapter = adapter

        sortSpinner.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>, view: View, position: Int, id: Long) {
                when (position) {
                    0 -> sortByDeadline() // Sort by deadline
                    1 -> sortByPriority()  // Sort by priority
                }
            }

            override fun onNothingSelected(parent: AdapterView<*>) {
                // No action needed
            }
        }
    }

    private fun sortByDeadline() {
        taskViewModel.tasksSortedByDeadline.observe(this) { tasks ->
            adapter.updateData(tasks) // Update adapter with sorted tasks
        }
    }

    private fun sortByPriority() {
        taskViewModel.tasksSortedByPriority.observe(this) { tasks ->
            adapter.updateData(tasks) // Update adapter with sorted tasks
        }
    }
}

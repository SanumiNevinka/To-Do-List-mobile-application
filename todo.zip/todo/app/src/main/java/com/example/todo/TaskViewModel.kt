package com.example.todo

import androidx.lifecycle.LiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.launch
import androidx.lifecycle.asLiveData

class TaskViewModel(private val repository: TaskRepository) : ViewModel() {

    // LiveData for observing all tasks
    val allTasks: LiveData<List<CardInfo>> = repository.getAllTasks().asLiveData()

    // Function to insert a new task using Coroutine
    fun insert(task: CardInfo) {
        viewModelScope.launch {
            try {
                repository.insert(task)
            } catch (e: Exception) {
                // Handle the error (e.g., log it, update a LiveData for error messages)
            }
        }
    }

    // Function to update an existing task using Coroutine
    fun update(task: CardInfo) {
        viewModelScope.launch {
            repository.update(task)
        }
    }

    // Function to delete a task using Coroutine
    fun delete(task: CardInfo) {
        viewModelScope.launch {
            repository.delete(task)
        }
    }

    // LiveData to observe tasks sorted by priority
    val tasksSortedByPriority: LiveData<List<CardInfo>> = repository.getTasksSortedByPriority().asLiveData()

    // LiveData to observe tasks sorted by deadline
    val tasksSortedByDeadline: LiveData<List<CardInfo>> = repository.getTasksSortedByDeadline().asLiveData() // Corrected

    // Function to filter tasks by deadline and observe them as LiveData
    fun getTasksFilteredByDeadline(deadline: String): LiveData<List<CardInfo>> {
        return repository.getTasksFilteredByDeadline(deadline).asLiveData()
    }
}

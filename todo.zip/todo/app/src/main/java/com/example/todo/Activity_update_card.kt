package com.example.todo

import android.content.Intent
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.Spinner
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class Activity_update_card : AppCompatActivity() {

    private lateinit var labelSpinner: Spinner

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_update_card)

        // Referencing the EditText views
        val createTitle = findViewById<EditText>(R.id.create_title)
        val createDescription = findViewById<EditText>(R.id.create_description)
        val createPriority = findViewById<EditText>(R.id.create_priority)
        val createDeadline = findViewById<EditText>(R.id.create_deadline)
        labelSpinner = findViewById(R.id.label_spinner) // Add labelSpinner reference
        val deleteButton = findViewById<Button>(R.id.delete_button)
        val updateButton = findViewById<Button>(R.id.update_button)

        // Retrieve position from intent extras
        val pos = intent.getIntExtra("id", -1)

        // Check if the position is valid
        if (pos != -1) {
            // Get the data from DataObject
            val task = DataObject.getData(pos)
            val title = task.title
            val description = task.description
            val priority = task.priority
            val deadline = task.deadline
            val label = task.label.joinToString(", ") // Convert List<String> to a string

            // Set the task data to the EditText views
            createTitle.setText(title)
            createDescription.setText(description)
            createPriority.setText(priority)
            createDeadline.setText(deadline)

            // Setup the spinner with labels and set the current label
            setupLabelSpinner(label)

            deleteButton.setOnClickListener {
                DataObject.deleteData(pos)
                navigateToMainActivity()
            }

            updateButton.setOnClickListener {
                val selectedLabel = labelSpinner.selectedItem.toString() // Get selected label

                DataObject.updateData(
                    pos,
                    createTitle.text.toString(),
                    createDescription.text.toString(),
                    createPriority.text.toString(),
                    createDeadline.text.toString(),
                    listOf(selectedLabel) // Update with selected label
                )
                Toast.makeText(this, "Task updated!", Toast.LENGTH_LONG).show()
                navigateToMainActivity()
            }
        }
    }

    private fun setupLabelSpinner(currentLabel: String) {
        val labels = arrayOf("Work", "Personal", "Important", "Shopping")
        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, labels)
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        labelSpinner.adapter = adapter

        // Set the spinner to show the current label
        val labelIndex = labels.indexOf(currentLabel)
        if (labelIndex != -1) {
            labelSpinner.setSelection(labelIndex)
        }
    }

    // Helper function to navigate back to MainActivity
    private fun navigateToMainActivity() {
        val intent = Intent(this, MainActivity::class.java)
        startActivity(intent)
    }
}

package com.example.todo

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Update
import androidx.room.Delete
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface TaskDao {
    @Insert
    suspend fun insert(task: CardInfo)

    @Update
    suspend fun update(task: CardInfo)

    @Delete
    suspend fun delete(task: CardInfo)

    @Query("SELECT * FROM tasks")
    fun getAllTasks(): Flow<List<CardInfo>>

    @Query("SELECT * FROM tasks ORDER BY priority")
    fun getTasksSortedByPriority(): Flow<List<CardInfo>>

    @Query("SELECT * FROM tasks ORDER BY deadline")
    fun getTasksSortedByDeadline(): Flow<List<CardInfo>>

    @Query("SELECT * FROM tasks WHERE deadline = :deadline")
    fun getTasksFilteredByDeadline(deadline: String): Flow<List<CardInfo>>
}
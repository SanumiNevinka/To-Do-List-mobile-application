package com.example.todo

import android.app.AlarmManager
import android.app.DatePickerDialog
import android.app.PendingIntent
import android.app.TimePickerDialog
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.Spinner
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.launch
import java.util.*

class Activity_create_card : AppCompatActivity() {

    private lateinit var taskDao: TaskDao
    private lateinit var db: AppDatabase
    private var reminderTimestamp: Long? = null
    private lateinit var labelSpinner: Spinner
    private lateinit var reminderButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_create_card)

        db = AppDatabase.getDatabase(applicationContext)
        taskDao = db.taskDao()

        val saveButton = findViewById<Button>(R.id.save_button)
        val createTitle = findViewById<EditText>(R.id.create_title)
        val createDescription = findViewById<EditText>(R.id.create_description)
        val createPriority = findViewById<EditText>(R.id.create_priority)
        val createDeadline = findViewById<EditText>(R.id.create_deadline)

        labelSpinner = findViewById(R.id.label_spinner)
        reminderButton = findViewById(R.id.reminder_button)

        setupLabelSpinner()
        setupReminderButton()

        saveButton.setOnClickListener {
            val title = createTitle.text.toString().trim()
            val description = createDescription.text.toString().trim()
            val priority = createPriority.text.toString().trim()
            val deadline = createDeadline.text.toString().trim()
            val label = labelSpinner.selectedItem.toString()

            // Validate the input fields
            if (title.isNotEmpty() && priority.isNotEmpty() && deadline.isNotEmpty()) {
                // Convert the selected label into a list
                val labelList = listOf(label) // Create a list containing the selected label

                // Insert into Room
                lifecycleScope.launch {
                    taskDao.insert(CardInfo(
                        title = title,
                        description = description,
                        priority = priority,
                        deadline = deadline,
                        label = labelList, // Pass label as a list
                        reminder = reminderTimestamp
                    ))
                    setReminder(reminderTimestamp) // Set reminder notification
                    startActivity(Intent(this@Activity_create_card, MainActivity::class.java))
                    finish() // Close this activity
                }
            } else {
                Toast.makeText(this, "Please fill out all required fields", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun setupLabelSpinner() {
        val labels = arrayOf("Work", "Personal", "Important", "Shopping") // Add your labels here
        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, labels)
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        labelSpinner.adapter = adapter
    }

    private fun setupReminderButton() {
        reminderButton.setOnClickListener {
            showDateTimePicker()
        }
    }

    private fun showDateTimePicker() {
        val calendar = Calendar.getInstance()
        val datePicker = DatePickerDialog(this, { _, year, month, dayOfMonth ->
            val timePicker = TimePickerDialog(this, { _, hourOfDay, minute ->
                calendar.set(year, month, dayOfMonth, hourOfDay, minute)
                reminderTimestamp = calendar.timeInMillis // Store the reminder timestamp
            }, calendar.get(Calendar.HOUR_OF_DAY), calendar.get(Calendar.MINUTE), true)
            timePicker.show()
        }, calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH), calendar.get(Calendar.DAY_OF_MONTH))
        datePicker.show()
    }

    private fun setReminder(reminderTime: Long?) {
        reminderTime?.let {
            val alarmIntent = Intent(this, ReminderReceiver::class.java)
            val pendingIntent = PendingIntent.getBroadcast(this, 0, alarmIntent, PendingIntent.FLAG_UPDATE_CURRENT)

            val alarmManager = getSystemService(Context.ALARM_SERVICE) as AlarmManager
            alarmManager.setExact(AlarmManager.RTC_WAKEUP, it, pendingIntent) // Set exact reminder
        }
    }
}

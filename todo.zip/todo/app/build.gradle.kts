plugins {
    // Applying Android and Kotlin plugins using the correct syntax
    alias(libs.plugins.android.application)
    alias(libs.plugins.jetbrains.kotlin.android)
    kotlin("kapt") // Applying KAPT plugin for Room annotation processing
}

android {
    namespace = "com.example.todo" // Your app’s package name
    compileSdk = 34 // Compiling against Android SDK 34

    defaultConfig {
        applicationId = "com.example.todo" // Your app's unique ID
        minSdk = 24 // Minimum Android SDK version supported
        targetSdk = 34 // Target Android SDK version
        versionCode = 1 // App version code
        versionName = "1.0" // App version name

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner" // Test runner
    }

    buildTypes {
        getByName("release") {
            isMinifyEnabled = false // Disable code shrinking for release builds
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro" // ProGuard rules for release build
            )
        }
    }

    compileOptions {
        // Set Java compatibility versions for Android and Kotlin compatibility
        sourceCompatibility = JavaVersion.VERSION_1_8
        targetCompatibility = JavaVersion.VERSION_1_8
    }

    kotlinOptions {
        jvmTarget = "1.8" // Set Kotlin JVM target to 1.8 for compatibility with Java 8
    }
}

dependencies {
    // AndroidX and Jetpack dependencies
    implementation(libs.androidx.core.ktx) // Core Kotlin extensions for AndroidX
    implementation(libs.androidx.appcompat) // AppCompat support library
    implementation(libs.material) // Material Design components
    implementation(libs.androidx.activity) // Activity support library
    implementation(libs.androidx.constraintlayout) // ConstraintLayout for responsive layouts

    // Room Database dependencies
    implementation("androidx.room:room-runtime:2.5.0")
    kapt("androidx.room:room-compiler:2.5.0") // For annotation processing

    // Coroutines support for Room
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-core:1.6.0")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.6.0")
    implementation ("androidx.lifecycle:lifecycle-viewmodel-ktx:2.5.1")
    implementation ("androidx.lifecycle:lifecycle-livedata-ktx:2.5.1")
    implementation ("androidx.room:room-ktx:2.5.0")


    // Unit and UI testing dependencies
    testImplementation(libs.junit) // JUnit for unit testing
    androidTestImplementation(libs.androidx.junit) // AndroidX test framework
    androidTestImplementation(libs.androidx.espresso.core) // Espresso for UI testing
}







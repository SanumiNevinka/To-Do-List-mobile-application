package com.example.todo

import androidx.annotation.WorkerThread
import kotlinx.coroutines.flow.Flow

class TaskRepository(private val taskDao: TaskDao) {

    // Insert a task into the database using Coroutines
    @WorkerThread
    suspend fun insert(task: CardInfo) {
        taskDao.insert(task)
    }

    // Update an existing task in the database
    @WorkerThread
    suspend fun update(task: CardInfo) {
        taskDao.update(task)
    }

    // Delete a task from the database
    @WorkerThread
    suspend fun delete(task: CardInfo) {
        taskDao.delete(task)
    }

    // Retrieve all tasks as a Flow (for observing in ViewModel)
    @WorkerThread
    fun getAllTasks(): Flow<List<CardInfo>> {
        return taskDao.getAllTasks()
    }

    // Retrieve tasks sorted by priority as a Flow
    @WorkerThread
    fun getTasksSortedByPriority(): Flow<List<CardInfo>> {
        return taskDao.getTasksSortedByPriority()
    }

    // Retrieve tasks sorted by deadline as a Flow
    @WorkerThread
    fun getTasksSortedByDeadline(): Flow<List<CardInfo>> {
        return taskDao.getTasksSortedByDeadline()
    }

    // Retrieve tasks filtered by deadline as a Flow
    @WorkerThread
    fun getTasksFilteredByDeadline(deadline: String): Flow<List<CardInfo>> {
        return taskDao.getTasksFilteredByDeadline(deadline)
    }
}

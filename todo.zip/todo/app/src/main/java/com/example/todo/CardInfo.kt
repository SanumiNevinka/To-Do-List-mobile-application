package com.example.todo

import androidx.room.Entity
import androidx.room.PrimaryKey
import androidx.room.TypeConverters

@Entity(tableName = "tasks")
@TypeConverters(Converters::class)
data class CardInfo(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    var title: String,
    var description: String,
    var priority: String,
    var deadline: String,
    var label: List<String> = emptyList(),
    var reminder: Long? = null
)

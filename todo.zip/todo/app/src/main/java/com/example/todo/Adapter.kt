package com.example.todo

import android.content.Intent
import android.graphics.Color
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import java.util.Date

class Adapter(private var data: List<CardInfo>) : RecyclerView.Adapter<Adapter.ViewHolder>() {

    class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        var title: TextView = itemView.findViewById(R.id.title)
        var description: TextView = itemView.findViewById(R.id.description)
        var priority: TextView = itemView.findViewById(R.id.priority)
        var deadline: TextView = itemView.findViewById(R.id.deadline)
        var layout: LinearLayout = itemView.findViewById(R.id.mylayout)
        var labels: TextView = itemView.findViewById(R.id.labels) // Add labels TextView
        var reminder: TextView = itemView.findViewById(R.id.reminder) // Add reminder TextView
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val itemView = LayoutInflater.from(parent.context).inflate(R.layout.activity_view, parent, false)
        return ViewHolder(itemView)
    }

    override fun getItemCount(): Int {
        return data.size
    }

    fun updateData(newTasks: List<CardInfo>) {
        data = newTasks
        notifyDataSetChanged()
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val task = data[position]

        // Set the background color based on priority
        when (task.priority.toLowerCase()) {
            "high" -> holder.layout.setBackgroundColor(Color.parseColor("#F05454"))
            "medium" -> holder.layout.setBackgroundColor(Color.parseColor("#EDC988"))
            "low" -> holder.layout.setBackgroundColor(Color.parseColor("#15B392"))
        }

        // Bind data to the views
        holder.title.text = task.title
        holder.description.text = task.description ?: "No description available"
        holder.priority.text = task.priority
        holder.deadline.text = "Deadline: ${task.deadline}"

        // Display labels
        holder.labels.text = task.label.joinToString(", ") // Convert List<String> to a comma-separated String

        // Display reminder if set
        holder.reminder.text = task.reminder?.let { Date(it).toString() } ?: "No reminder set" // Convert Long to String

        // Set an onClickListener for item update
        holder.itemView.setOnClickListener {
            val intent = Intent(holder.itemView.context, Activity_update_card::class.java)
            intent.putExtra("id", position)
            holder.itemView.context.startActivity(intent)
        }
    }
}

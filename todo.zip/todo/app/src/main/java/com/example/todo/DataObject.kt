package com.example.todo

object DataObject {
    var listdata = mutableListOf<CardInfo>()

    // Updated setData method to include label and reminder parameters
    fun setData(
        title: String,
        description: String,
        priority: String,
        deadline: String,
        labels: List<String> = emptyList(), // Default value to empty list
        reminder: Long? = null // Default value to null
    ) {
        listdata.add(
            CardInfo(
                title = title,
                description = description,
                priority = priority,
                deadline = deadline,
                label = labels, // Use `label` here
                reminder = reminder // Pass reminder to CardInfo
            )
        )
    }

    fun getAllData(): List<CardInfo> {
        return listdata
    }

    fun deleteAll() {
        listdata.clear()
    }

    fun getData(pos: Int): CardInfo {
        return listdata[pos]
    }

    fun deleteData(pos: Int) {
        listdata.removeAt(pos)
    }

    // Updated updateData method to include label and reminder parameters
    fun updateData(
        pos: Int,
        title: String,
        description: String,
        priority: String,
        deadline: String,
        labels: List<String> = emptyList(), // Use `labels` parameter
        reminder: Long? = null
    ) {
        listdata[pos].apply {
            this.title = title
            this.description = description
            this.priority = priority
            this.deadline = deadline
            this.label = labels // Update to use `labels` parameter
            this.reminder = reminder // Update reminder
        }
    }
}


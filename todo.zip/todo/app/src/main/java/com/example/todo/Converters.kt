package com.example.todo

import androidx.room.TypeConverter

class Converters {
    @TypeConverter
    fun fromString(value: String?): List<String>? {
        return value?.split("|") // Using pipe as the delimiter to avoid issues with commas
    }

    @TypeConverter
    fun fromList(value: List<String>?): String? {
        return value?.joinToString("|") // Using pipe to join
    }
}